import React, { useState } from 'react';
import { Heart, X, MessageCircle, UserRound, SlidersHorizontal, Sparkles, ShieldCheck, MapPin, ChevronRight, Settings, Home } from 'lucide-react';

const people = [
  {name:'Aarav', age:22, city:'Pune', about:'Coffee, weekend hikes and discovering new music.', interests:['Music','Travel','Coffee'], color:'linear-gradient(135deg,#c7b5ff,#f4d8ed)', initials:'A'},
  {name:'Mira', age:23, city:'Mumbai', about:'Bookstores, art galleries and long conversations.', interests:['Art','Books','Food'], color:'linear-gradient(135deg,#f7c6dc,#c8c1ff)', initials:'M'},
  {name:'Ishaan', age:24, city:'Nashik', about:'Learning new things and exploring local cafés.', interests:['Tech','Movies','Cafés'], color:'linear-gradient(135deg,#b7d9f7,#d9c9ff)', initials:'I'}
];
export default function App(){
 const [index,setIndex]=useState(0), [tab,setTab]=useState('Discover'), [notice,setNotice]=useState('');
 const person=people[index%people.length];
 const act=(kind)=>{setNotice(kind==='like'?'Like saved in this local demo.':'Profile passed in this local demo.');setIndex(i=>i+1);};
 return <div className="app-shell">
  <aside className="sidebar"><div className="brand"><span className="brand-icon"><Heart size={20} fill="white"/></span><span>LoveConnect</span></div>
   <div className="nav-label">MENU</div>
   {['Discover','Matches','Messages','Profile'].map((t,i)=><button key={t} className={'nav-item '+(tab===t?'active':'')} onClick={()=>setTab(t)}>{[<Home/>,<Heart/>,<MessageCircle/>,<UserRound/>][i]}{t}</button>)}
   <div className="sidebar-bottom"><div className="safety"><ShieldCheck size={18}/><div><b>Safety first</b><small>Demo experience · No real chats</small></div></div><button className="nav-item" onClick={()=>setTab('Settings')}><Settings/>Settings</button></div>
  </aside>
  <main className="main">
   <header className="topbar"><div><div className="eyebrow">YOUR SPACE TO CONNECT</div><h1>{tab==='Discover'?'Discover people':tab}</h1></div><button className="filter"><SlidersHorizontal size={17}/> Filters</button></header>
   {tab==='Discover'?<section className="discover-layout">
    <div className="intro"><span className="pill"><Sparkles size={14}/> Curated discovery</span><h2>Good connections<br/><em>start here.</em></h2><p>Explore sample profiles in this private UI prototype.</p></div>
    <div className="profile-card">
      <div className="photo" style={{background:person.color}}><div className="avatar">{person.initials}</div><span className="photo-tag">SAMPLE PROFILE</span><div className="photo-gradient"></div><div className="person-heading"><h2>{person.name}, {person.age}</h2><span><MapPin size={14}/>{person.city}</span></div></div>
      <div className="profile-info"><p>{person.about}</p><div className="tags">{person.interests.map(x=><span key={x}>{x}</span>)}</div><div className="actions"><button className="pass" onClick={()=>act('pass')} aria-label="Pass"><X/></button><button className="like" onClick={()=>act('like')} aria-label="Like"><Heart fill="white"/></button></div>{notice&&<small className="notice">{notice}</small>}</div>
    </div>
    <div className="side-note"><div className="note-icon"><ShieldCheck/></div><b>Private demo</b><p>All profiles are fictional sample data. No account, location tracking or messaging is connected.</p></div>
   </section>:<section className="placeholder"><div className="placeholder-icon">{tab==='Matches'?<Heart/>:tab==='Messages'?<MessageCircle/>:tab==='Profile'?<UserRound/>:<Settings/>}</div><h2>{tab==='Matches'?'Your sample matches':tab==='Messages'?'Messages demo':tab==='Profile'?'Your profile':'Settings'}</h2><p>{tab==='Matches'?'Matching is simulated locally in this prototype.':tab==='Messages'?'Real messaging is disabled in this educational prototype.':'This screen will be added in the next development stage.'}</p><button className="primary" onClick={()=>setTab('Discover')}>Back to Discover <ChevronRight size={16}/></button></section>}
   <footer>LoveConnect <span>•</span> UI prototype <span>•</span> Fictional sample profiles only</footer>
  </main>
 </div>
}